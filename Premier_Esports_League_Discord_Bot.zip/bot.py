import os
import sqlite3
import threading
from datetime import datetime
from flask import Flask

import discord
from discord import app_commands
from discord.ext import commands

TOKEN = os.getenv("DISCORD_TOKEN")
APPLICATION_CHANNEL_ID = int(os.getenv("APPLICATION_CHANNEL_ID", "0"))

intents = discord.Intents.default()
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents)

DB = "league.db"

def get_db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    con = get_db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS teams(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        captain_id INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS matches(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        team1 TEXT NOT NULL,
        team2 TEXT NOT NULL,
        score1 INTEGER NOT NULL,
        score2 INTEGER NOT NULL,
        official INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS applications(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        game TEXT NOT NULL,
        team_name TEXT NOT NULL,
        experience TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS scrims(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        host_team TEXT NOT NULL,
        game TEXT NOT NULL,
        mode TEXT NOT NULL,
        scheduled TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'open',
        opponent TEXT
    );
    """)
    con.commit()
    con.close()

def is_staff(interaction):
    return interaction.user.guild_permissions.manage_guild

def make_standings():
    con = get_db()
    teams = con.execute("SELECT name FROM teams").fetchall()
    data = {x["name"]: {"W":0,"L":0,"T":0,"PTS":0,"GP":0} for x in teams}

    for m in con.execute("SELECT * FROM matches WHERE official=1").fetchall():
        for team in (m["team1"], m["team2"]):
            data.setdefault(team, {"W":0,"L":0,"T":0,"PTS":0,"GP":0})

        data[m["team1"]]["GP"] += 1
        data[m["team2"]]["GP"] += 1

        if m["score1"] > m["score2"]:
            data[m["team1"]]["W"] += 1
            data[m["team2"]]["L"] += 1
            data[m["team1"]]["PTS"] += 3
        elif m["score2"] > m["score1"]:
            data[m["team2"]]["W"] += 1
            data[m["team1"]]["L"] += 1
            data[m["team2"]]["PTS"] += 3
        else:
            data[m["team1"]]["T"] += 1
            data[m["team2"]]["T"] += 1
            data[m["team1"]]["PTS"] += 1
            data[m["team2"]]["PTS"] += 1

    con.close()
    return sorted(data.items(), key=lambda x: (-x[1]["PTS"], -x[1]["W"], x[1]["L"], x[0].lower()))

@bot.event
async def on_ready():
    init_db()
    await bot.tree.sync()
    print(f"Logged in as {bot.user}")

@bot.tree.command(name="standings", description="Show Premier Esports League standings.")
async def standings(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🏆 PREMIER ESPORTS LEAGUE",
        description="Official League Standings",
        color=discord.Color.red()
    )
    rows = make_standings()

    if not rows:
        embed.add_field(name="No teams yet", value="Staff can use `/addteam`.", inline=False)
    else:
        lines = ["**#  TEAM                         W   L   T   PTS**"]
        for i, (name, s) in enumerate(rows, 1):
            lines.append(
                f"`{i:<2} {name[:26]:<26} {s['W']:>2}  {s['L']:>2}  {s['T']:>2}  {s['PTS']:>3}`"
            )
        embed.add_field(name="Standings", value="\n".join(lines), inline=False)

    await interaction.response.send_message(embed=embed)

@bot.tree.command(name="addteam", description="Add a team to the league.")
async def addteam(interaction: discord.Interaction, name: str, captain: discord.Member):
    if not is_staff(interaction):
        return await interaction.response.send_message("Staff only.", ephemeral=True)

    con = get_db()
    try:
        con.execute("INSERT INTO teams(name,captain_id) VALUES(?,?)", (name, captain.id))
        con.commit()
        msg = f"✅ **{name}** has been added to the league."
    except sqlite3.IntegrityError:
        msg = "That team already exists."
    con.close()
    await interaction.response.send_message(msg)

@bot.tree.command(name="addmatch", description="Record an official league match.")
async def addmatch(interaction: discord.Interaction, team1: str, team2: str, score1: int, score2: int):
    if not is_staff(interaction):
        return await interaction.response.send_message("Staff only.", ephemeral=True)
    if team1.lower() == team2.lower() or score1 < 0 or score2 < 0:
        return await interaction.response.send_message("Invalid match.", ephemeral=True)

    con = get_db()
    cur = con.execute(
        """INSERT INTO matches(team1,team2,score1,score2,official,created_at)
           VALUES(?,?,?,?,1,?)""",
        (team1, team2, score1, score2, datetime.utcnow().isoformat())
    )
    con.commit()
    match_id = cur.lastrowid
    con.close()
    await interaction.response.send_message(
        f"📊 Match **#{match_id}** recorded: **{team1} {score1}–{score2} {team2}**"
    )

@bot.tree.command(name="removematch", description="Remove an official match.")
async def removematch(interaction: discord.Interaction, match_id: int):
    if not is_staff(interaction):
        return await interaction.response.send_message("Staff only.", ephemeral=True)
    con = get_db()
    cur = con.execute("DELETE FROM matches WHERE id=?", (match_id,))
    con.commit()
    con.close()
    await interaction.response.send_message(
        "🗑️ Match removed." if cur.rowcount else "No match found."
    )

class ApplicationModal(discord.ui.Modal, title="Premier Esports League Application"):
    game = discord.ui.TextInput(label="Game", placeholder="Rocket League / Fortnite / R6 / Apex / Gorilla Tag")
    team = discord.ui.TextInput(label="Team Name")
    experience = discord.ui.TextInput(
        label="Experience",
        style=discord.TextStyle.paragraph,
        max_length=1000
    )

    async def on_submit(self, interaction: discord.Interaction):
        con = get_db()
        cur = con.execute(
            """INSERT INTO applications(user_id,game,team_name,experience,created_at)
               VALUES(?,?,?,?,?)""",
            (
                interaction.user.id,
                self.game.value,
                self.team.value,
                self.experience.value,
                datetime.utcnow().isoformat()
            )
        )
        con.commit()
        application_id = cur.lastrowid
        con.close()

        embed = discord.Embed(
            title=f"📋 Application #{application_id}",
            color=discord.Color.red()
        )
        embed.add_field(name="Applicant", value=interaction.user.mention, inline=False)
        embed.add_field(name="Game", value=self.game.value)
        embed.add_field(name="Team", value=self.team.value)
        embed.add_field(name="Experience", value=self.experience.value[:1024], inline=False)

        await interaction.response.send_message(
            "✅ Your application has been submitted.", ephemeral=True
        )

        channel = interaction.guild.get_channel(APPLICATION_CHANNEL_ID)
        if channel:
            await channel.send(
                embed=embed,
                view=ApplicationView(application_id)
            )

class ApplicationView(discord.ui.View):
    def __init__(self, application_id):
        super().__init__(timeout=None)
        self.application_id = application_id

    @discord.ui.button(label="Accept", style=discord.ButtonStyle.success)
    async def accept(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_staff(interaction):
            return await interaction.response.send_message("Staff only.", ephemeral=True)

        con = get_db()
        con.execute(
            "UPDATE applications SET status='accepted' WHERE id=?",
            (self.application_id,)
        )
        con.commit()
        con.close()
        await interaction.response.send_message("✅ Application accepted.")

    @discord.ui.button(label="Deny", style=discord.ButtonStyle.danger)
    async def deny(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_staff(interaction):
            return await interaction.response.send_message("Staff only.", ephemeral=True)

        con = get_db()
        con.execute(
            "UPDATE applications SET status='denied' WHERE id=?",
            (self.application_id,)
        )
        con.commit()
        con.close()
        await interaction.response.send_message("❌ Application denied.")

@bot.tree.command(name="apply", description="Apply to Premier Esports League.")
async def apply(interaction: discord.Interaction):
    await interaction.response.send_modal(ApplicationModal())

@bot.tree.command(name="scrim", description="Create a scrim request.")
async def scrim(interaction: discord.Interaction, host_team: str, game: str, mode: str, scheduled: str):
    if not is_staff(interaction):
        return await interaction.response.send_message("Staff only.", ephemeral=True)

    con = get_db()
    cur = con.execute(
        "INSERT INTO scrims(host_team,game,mode,scheduled) VALUES(?,?,?,?)",
        (host_team, game, mode, scheduled)
    )
    con.commit()
    scrim_id = cur.lastrowid
    con.close()

    embed = discord.Embed(
        title=f"⚔️ PREMIER SCRIM REQUEST #{scrim_id}",
        color=discord.Color.red()
    )
    embed.description = (
        f"**Team:** {host_team}\n"
        f"**Game:** {game}\n"
        f"**Format:** {mode}\n"
        f"**Time:** {scheduled}\n\n"
        "Looking for an opponent."
    )
    await interaction.response.send_message(embed=embed, view=ScrimView(scrim_id))

class ScrimView(discord.ui.View):
    def __init__(self, scrim_id):
        super().__init__(timeout=None)
        self.scrim_id = scrim_id

    @discord.ui.button(label="Join Scrim", style=discord.ButtonStyle.success)
    async def join(self, interaction: discord.Interaction, button: discord.ui.Button):
        con = get_db()
        row = con.execute("SELECT * FROM scrims WHERE id=?", (self.scrim_id,)).fetchone()

        if not row or row["status"] != "open":
            con.close()
            return await interaction.response.send_message(
                "This scrim is no longer open.", ephemeral=True
            )

        opponent = interaction.user.display_name
        con.execute(
            "UPDATE scrims SET opponent=?,status='accepted' WHERE id=?",
            (opponent, self.scrim_id)
        )
        con.commit()
        con.close()

        await interaction.response.send_message(
            f"🔥 **SCRIM CONFIRMED**\n"
            f"**{row['host_team']}** vs **{opponent}**\n"
            f"🎮 {row['game']} • {row['mode']}\n"
            f"🕐 {row['scheduled']}"
        )

    @discord.ui.button(label="Cancel", style=discord.ButtonStyle.danger)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not is_staff(interaction):
            return await interaction.response.send_message("Staff only.", ephemeral=True)

        con = get_db()
        con.execute("UPDATE scrims SET status='cancelled' WHERE id=?", (self.scrim_id,))
        con.commit()
        con.close()
        await interaction.response.send_message("🛑 Scrim cancelled.")

@bot.tree.command(name="scrims", description="Show open scrim requests.")
async def scrims(interaction: discord.Interaction):
    con = get_db()
    rows = con.execute(
        "SELECT * FROM scrims WHERE status='open' ORDER BY id DESC LIMIT 10"
    ).fetchall()
    con.close()

    embed = discord.Embed(
        title="⚔️ OPEN PREMIER SCRIMS",
        color=discord.Color.red()
    )

    if not rows:
        embed.description = "No open scrims right now."
    else:
        embed.description = "\n\n".join(
            f"**#{r['id']} — {r['host_team']}**\n"
            f"🎮 {r['game']} • {r['mode']}\n"
            f"🕐 {r['scheduled']}"
            for r in rows
        )

    await interaction.response.send_message(embed=embed)

# Render free Web Service health endpoint
app = Flask(__name__)

@app.get("/")
def health():
    return "Premier Esports League bot is online.", 200

def run_web():
    port = int(os.getenv("PORT", "10000"))
    app.run(host="0.0.0.0", port=port)

init_db()
threading.Thread(target=run_web, daemon=True).start()
bot.run(TOKEN)
