# Premier Esports League Discord Bot

A Discord bot for **Premier Esports League** with:
- League standings
- Team management
- Official match results
- Applications with staff Accept/Deny buttons
- Scrim requests with Join/Cancel buttons
- SQLite database storage

## Setup

1. Install Python 3.11+.
2. Open a terminal in this folder.
3. Run:
   `pip install -r requirements.txt`
4. Create a Discord application/bot in the Discord Developer Portal.
5. Copy `.env.example` to `.env` and fill in the bot token and application channel ID.
6. Export the variables or use a dotenv loader.
7. Run:
   `python bot.py`

### Environment variables

`DISCORD_TOKEN` = your bot token  
`APPLICATION_CHANNEL_ID` = the private channel where applications are sent

## Main commands

`/apply` — application form  
`/standings` — league standings  
`/addteam` — staff adds a team  
`/addmatch` — staff records an official match  
`/removematch` — staff removes a match  
`/scrim` — staff creates a scrim request  
`/scrims` — shows open scrims

The supplied `premier_banner.jpeg` is the official banner asset you provided. Use it as the Discord bot/application/server banner in Discord's settings.


## Free hosting: Render

This package includes `render.yaml` and a small Flask health endpoint so it can run as a Render Web Service.

Important: Render's free services have limitations and can restart/spin down; local SQLite files are not persistent on free Render services. That means league data can be lost after a restart/redeploy. For a serious league, move the database to a persistent hosted database later.
